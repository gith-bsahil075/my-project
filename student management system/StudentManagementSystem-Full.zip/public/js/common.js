/**
 * Shared helpers for every page inside the app shell (dashboard, attendance,
 * marks, fees). Include this before the page's own script.
 */

/**
 * Wraps fetch(): on any 401 response it redirects to the login page instead
 * of letting each page handle "not logged in" separately.
 */
async function apiFetch(url, options) {
  const response = await fetch(url, options);
  if (response.status === 401) {
    window.location.href = "index.html";
    throw new Error("Not logged in.");
  }
  return response;
}

async function apiRequest(url, options) {
  const response = await apiFetch(url, options);
  let data = null;
  try {
    data = await response.json();
  } catch (_) {
    // some responses have no body
  }
  if (!response.ok) {
    const message = (data && data.error) ? data.error : `Request failed (${response.status})`;
    throw new Error(message);
  }
  return data;
}

function wireLogoutButton() {
  const btn = document.getElementById("logoutBtn");
  if (!btn) return;
  btn.addEventListener("click", async () => {
    try {
      await fetch("/api/logout", { method: "POST" });
    } finally {
      window.location.href = "index.html";
    }
  });
}

document.addEventListener("DOMContentLoaded", wireLogoutButton);
