package util;

import java.time.Duration;
import java.time.Instant;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Simple in-memory session store. Session tokens live only as long as the
 * server process runs (restarting the server logs everyone out) -- which
 * is a fair tradeoff for a college project, and keeps this dependency-free.
 */
public final class SessionManager {

    private static final Duration SESSION_DURATION = Duration.ofHours(4);
    private static final Map<String, Instant> sessions = new ConcurrentHashMap<>();

    private SessionManager() {
    }

    public static String createSession() {
        String token = UUID.randomUUID().toString();
        sessions.put(token, Instant.now().plus(SESSION_DURATION));
        return token;
    }

    public static boolean isValid(String token) {
        if (token == null) {
            return false;
        }
        Instant expiry = sessions.get(token);
        return expiry != null && Instant.now().isBefore(expiry);
    }

    public static void invalidate(String token) {
        if (token != null) {
            sessions.remove(token);
        }
    }
}
