package server;

import com.sun.net.httpserver.HttpExchange;
import model.Student;
import service.StudentService;
import util.JsonUtil;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class StudentHandler {

    private final StudentService service;

    public StudentHandler(StudentService service) {
        this.service = service;
    }

    public void handle(HttpExchange exchange) {
        try {
            String path = exchange.getRequestURI().getPath();
            String idPart = path.replaceFirst("^/api/students/?", "");
            Integer id = null;
            if (!idPart.isBlank()) {
                try {
                    id = Integer.parseInt(idPart);
                } catch (NumberFormatException e) {
                    ResponseUtil.sendJson(exchange, 400, ResponseUtil.errorJson("Invalid student id in URL: " + idPart));
                    return;
                }
            }

            switch (exchange.getRequestMethod()) {
                case "GET" -> {
                    if (id == null) getAll(exchange);
                    else getOne(exchange, id);
                }
                case "POST" -> create(exchange);
                case "PUT" -> {
                    if (id == null) ResponseUtil.sendJson(exchange, 400, ResponseUtil.errorJson("Student id required in URL for update."));
                    else update(exchange, id);
                }
                case "DELETE" -> {
                    if (id == null) ResponseUtil.sendJson(exchange, 400, ResponseUtil.errorJson("Student id required in URL for delete."));
                    else delete(exchange, id);
                }
                default -> ResponseUtil.sendJson(exchange, 405, ResponseUtil.errorJson("Method not allowed."));
            }
        } catch (Exception e) {
            try {
                ResponseUtil.sendJson(exchange, 500, ResponseUtil.errorJson("Server error: " + e.getMessage()));
            } catch (IOException ignored) {
            }
        }
    }

    private void getAll(HttpExchange exchange) throws IOException {
        List<Student> students = service.getAllStudents();
        String json = students.stream().map(Student::toJson).collect(Collectors.joining(",", "[", "]"));
        ResponseUtil.sendJson(exchange, 200, json);
    }

    private void getOne(HttpExchange exchange, int id) throws IOException {
        Student s = service.searchStudent(id);
        if (s == null) {
            ResponseUtil.sendJson(exchange, 404, ResponseUtil.errorJson("No student found with id " + id + "."));
        } else {
            ResponseUtil.sendJson(exchange, 200, s.toJson());
        }
    }

    private void create(HttpExchange exchange) throws IOException {
        Map<String, String> body = JsonUtil.parseObject(ResponseUtil.readBody(exchange));
        try {
            String name = body.getOrDefault("name", "");
            int age = Integer.parseInt(body.getOrDefault("age", ""));
            String course = body.getOrDefault("course", "");
            double cgpa = Double.parseDouble(body.getOrDefault("cgpa", ""));

            int newId = service.nextAvailableId();
            String result = service.addStudent(newId, name, age, course, cgpa);
            if (result.startsWith("Error")) {
                ResponseUtil.sendJson(exchange, 400, ResponseUtil.errorJson(result));
                return;
            }
            ResponseUtil.sendJson(exchange, 201, service.searchStudent(newId).toJson());
        } catch (NumberFormatException e) {
            ResponseUtil.sendJson(exchange, 400, ResponseUtil.errorJson("Age and CGPA must be valid numbers."));
        }
    }

    private void update(HttpExchange exchange, int id) throws IOException {
        Map<String, String> body = JsonUtil.parseObject(ResponseUtil.readBody(exchange));
        try {
            String name = body.getOrDefault("name", "");
            int age = Integer.parseInt(body.getOrDefault("age", ""));
            String course = body.getOrDefault("course", "");
            double cgpa = Double.parseDouble(body.getOrDefault("cgpa", ""));

            String result = service.updateStudent(id, name, age, course, cgpa);
            if (result.startsWith("Error")) {
                int status = result.contains("No student found") ? 404 : 400;
                ResponseUtil.sendJson(exchange, status, ResponseUtil.errorJson(result));
                return;
            }
            ResponseUtil.sendJson(exchange, 200, service.searchStudent(id).toJson());
        } catch (NumberFormatException e) {
            ResponseUtil.sendJson(exchange, 400, ResponseUtil.errorJson("Age and CGPA must be valid numbers."));
        }
    }

    private void delete(HttpExchange exchange, int id) throws IOException {
        String result = service.deleteStudent(id);
        if (result.startsWith("Error")) {
            ResponseUtil.sendJson(exchange, 404, ResponseUtil.errorJson(result));
        } else {
            ResponseUtil.sendJson(exchange, 200, "{\"message\":\"Student deleted successfully.\"}");
        }
    }
}
