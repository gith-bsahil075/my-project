package service;

import dao.AdminDAO;
import util.SessionManager;

public class AuthService {

    private final AdminDAO adminDAO;

    public AuthService() {
        this.adminDAO = new AdminDAO();
    }

    /** Returns a new session token if the credentials are correct, otherwise null. */
    public String login(String username, String password) {
        if (adminDAO.verify(username, password)) {
            return SessionManager.createSession();
        }
        return null;
    }

    public void logout(String token) {
        SessionManager.invalidate(token);
    }
}
