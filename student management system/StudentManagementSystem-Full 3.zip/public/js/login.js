const loginForm = document.getElementById("loginForm");
const errorBanner = document.getElementById("errorBanner");
const loginBtn = document.getElementById("loginBtn");

loginForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  errorBanner.hidden = true;
  loginBtn.disabled = true;
  loginBtn.textContent = "Logging in...";

  const username = document.getElementById("username").value.trim();
  const password = document.getElementById("password").value;

  try {
    const response = await fetch("/api/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password }),
    });
    const data = await response.json().catch(() => null);

    if (!response.ok) {
      throw new Error((data && data.error) ? data.error : "Login failed.");
    }

    window.location.href = "dashboard.html";
  } catch (err) {
    errorBanner.textContent = err.message;
    errorBanner.hidden = false;
    loginBtn.disabled = false;
    loginBtn.textContent = "Log In";
  }
});
