# Student Management System (Java SE 21)

Two front ends, one shared backend. Built with plain Java SE 21 — no
external libraries, no database driver, no Maven/Gradle required for
either version.

- **Console version** (`Main.java`) — the original text-menu app.
- **Web version** (`ServerMain.java`) — a REST API + browser UI, using
  only `com.sun.net.httpserver` (built into the JDK).

Both share the exact same `model` / `dao` / `service` layers and the
exact same data file, so records you add in one show up in the other.

## Features
- Add / View / Search / Update / Delete students
- Data persists to `data/students.txt` (plain CSV, human-readable)
- Validation: duplicate IDs, blank names, age range, CGPA range (0-10)
- Web version: auto-generated IDs, colour-coded CGPA badges, inline
  add/edit form, delete confirmation

## Project Structure
```
StudentManagementSystem/
├── src/
│   ├── Main.java                 -> console entry point
│   ├── ServerMain.java           -> web entry point (starts the server)
│   ├── model/Student.java        -> Student data model (+ toJson)
│   ├── dao/
│   │   ├── StudentDAO.java       -> data-access interface
│   │   └── StudentDAOImpl.java   -> file-based implementation
│   ├── service/
│   │   └── StudentService.java   -> business logic + validation
│   ├── server/
│   │   └── ApiServer.java        -> REST API + static file hosting
│   └── util/
│       └── JsonUtil.java         -> tiny dependency-free JSON parser
├── public/                       -> the web frontend
│   ├── index.html
│   ├── style.css
│   └── script.js
├── data/
│   └── students.txt              -> auto-created on first save
└── .vscode/                      -> run configs for both versions
```

## How to Run in VS Code
1. Install the **Extension Pack for Java** (by Microsoft), if you don't
   already have it.
2. Open this folder in VS Code: `File -> Open Folder`.
3. Open the **Run and Debug** panel (`Ctrl+Shift+D`) and pick a
   configuration from the dropdown at the top:
   - **Launch Main (Console version)** -> runs in the Terminal panel.
   - **Launch ServerMain (Web version)** -> starts the server; then open
     **http://localhost:8080** in your browser.

   (Alternatively, just open `src/Main.java` or `src/ServerMain.java`
   and click the **Run** link above the `main` method.)

## How to Run from a Terminal (no VS Code needed)
Requires JDK 21+ (`java -version` / `javac -version` to check).

```bash
# from inside the StudentManagementSystem folder — compile everything once:
javac -d bin src/Main.java src/ServerMain.java src/model/Student.java src/dao/StudentDAO.java src/dao/StudentDAOImpl.java src/service/StudentService.java src/server/ApiServer.java src/util/JsonUtil.java

# then run whichever version you want:
java -cp bin Main          # console version
java -cp bin ServerMain    # web version -> open http://localhost:8080
```

## REST API (web version)
| Method | URL                    | Body (JSON)                  | Description        |
|--------|------------------------|-------------------------------|---------------------|
| GET    | `/api/students`        | –                              | List all students   |
| GET    | `/api/students/{id}`   | –                              | Get one student      |
| POST   | `/api/students`        | `{name, age, course, cgpa}`   | Create (auto ID)    |
| PUT    | `/api/students/{id}`   | `{name, age, course, cgpa}`   | Update               |
| DELETE | `/api/students/{id}`   | –                              | Delete               |

## Notes
- Data is stored as plain CSV lines in `data/students.txt` — open it in
  any text editor to watch it change as you use either version.
- Everything (HTML/CSS/JS, JSON parsing, HTTP server) is hand-written on
  top of the plain JDK, on purpose — nothing to install, nothing that
  can fail to download, and it's easy to explain line-by-line in an
  interview.
- Because storage sits behind the `StudentDAO` interface, swapping in a
  real database later (JDBC + SQLite/MySQL) only means writing a new
  `StudentDAO` implementation — `Main`, `ServerMain`, `ApiServer` and
  `StudentService` would not need to change.
