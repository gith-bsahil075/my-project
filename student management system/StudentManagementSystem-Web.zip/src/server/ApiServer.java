package server;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.SimpleFileServer;
import model.Student;
import service.StudentService;
import util.JsonUtil;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Backend layer: a REST API over StudentService, plus static file hosting
 * for the browser frontend in /public — all on one port, using only
 * classes built into the JDK (com.sun.net.httpserver), so no external
 * dependency (Maven/Spring Boot/etc.) is needed to run this project.
 *
 * Endpoints:
 *   GET    /api/students        -> list all students
 *   GET    /api/students/{id}   -> one student
 *   POST   /api/students        -> create (JSON body: name, age, course, cgpa)
 *   PUT    /api/students/{id}   -> update (JSON body: name, age, course, cgpa)
 *   DELETE /api/students/{id}   -> delete
 */
public class ApiServer {

    private final StudentService service;
    private final int port;

    public ApiServer(StudentService service, int port) {
        this.service = service;
        this.port = port;
    }

    public void start(Path publicDir) throws IOException {
        HttpServer server = HttpServer.create(new InetSocketAddress(port), 0);

        // Serves index.html / style.css / script.js from /public
        server.createContext("/", SimpleFileServer.createFileHandler(publicDir));

        // REST API for student CRUD, reusing the exact same StudentService
        // that the console app (Main.java) uses.
        server.createContext("/api/students", this::handleStudents);

        server.setExecutor(null); // default executor is fine for a student-project scale app
        server.start();

        System.out.println("Server running -> http://localhost:" + port);
        System.out.println("Press Ctrl+C in this terminal to stop the server.");
    }

    private void handleStudents(HttpExchange exchange) {
        try {
            String path = exchange.getRequestURI().getPath();
            String idPart = path.replaceFirst("^/api/students/?", "");
            Integer id = null;
            if (!idPart.isBlank()) {
                try {
                    id = Integer.parseInt(idPart);
                } catch (NumberFormatException e) {
                    sendJson(exchange, 400, errorJson("Invalid student id in URL: " + idPart));
                    return;
                }
            }

            switch (exchange.getRequestMethod()) {
                case "GET" -> {
                    if (id == null) handleGetAll(exchange);
                    else handleGetOne(exchange, id);
                }
                case "POST" -> handleCreate(exchange);
                case "PUT" -> {
                    if (id == null) sendJson(exchange, 400, errorJson("Student id required in URL for update."));
                    else handleUpdate(exchange, id);
                }
                case "DELETE" -> {
                    if (id == null) sendJson(exchange, 400, errorJson("Student id required in URL for delete."));
                    else handleDelete(exchange, id);
                }
                default -> sendJson(exchange, 405, errorJson("Method not allowed."));
            }
        } catch (Exception e) {
            try {
                sendJson(exchange, 500, errorJson("Server error: " + e.getMessage()));
            } catch (IOException ignored) {
                // response already broken; nothing more we can do
            }
        }
    }

    private void handleGetAll(HttpExchange exchange) throws IOException {
        List<Student> students = service.getAllStudents();
        String json = "[" + students.stream().map(Student::toJson).collect(Collectors.joining(",")) + "]";
        sendJson(exchange, 200, json);
    }

    private void handleGetOne(HttpExchange exchange, int id) throws IOException {
        Student s = service.searchStudent(id);
        if (s == null) {
            sendJson(exchange, 404, errorJson("No student found with id " + id + "."));
        } else {
            sendJson(exchange, 200, s.toJson());
        }
    }

    private void handleCreate(HttpExchange exchange) throws IOException {
        Map<String, String> body = JsonUtil.parseObject(readBody(exchange));
        try {
            String name = body.getOrDefault("name", "");
            int age = parseIntSafe(body.get("age"));
            String course = body.getOrDefault("course", "");
            double cgpa = parseDoubleSafe(body.get("cgpa"));

            int newId = service.nextAvailableId();
            String result = service.addStudent(newId, name, age, course, cgpa);

            if (result.startsWith("Error")) {
                sendJson(exchange, 400, errorJson(result));
                return;
            }
            sendJson(exchange, 201, service.searchStudent(newId).toJson());
        } catch (NumberFormatException e) {
            sendJson(exchange, 400, errorJson("Age and CGPA must be valid numbers."));
        }
    }

    private void handleUpdate(HttpExchange exchange, int id) throws IOException {
        Map<String, String> body = JsonUtil.parseObject(readBody(exchange));
        try {
            String name = body.getOrDefault("name", "");
            int age = parseIntSafe(body.get("age"));
            String course = body.getOrDefault("course", "");
            double cgpa = parseDoubleSafe(body.get("cgpa"));

            String result = service.updateStudent(id, name, age, course, cgpa);
            if (result.startsWith("Error")) {
                int status = result.contains("No student found") ? 404 : 400;
                sendJson(exchange, status, errorJson(result));
                return;
            }
            sendJson(exchange, 200, service.searchStudent(id).toJson());
        } catch (NumberFormatException e) {
            sendJson(exchange, 400, errorJson("Age and CGPA must be valid numbers."));
        }
    }

    private void handleDelete(HttpExchange exchange, int id) throws IOException {
        String result = service.deleteStudent(id);
        if (result.startsWith("Error")) {
            sendJson(exchange, 404, errorJson(result));
        } else {
            sendJson(exchange, 200, "{\"message\":\"Student deleted successfully.\"}");
        }
    }

    private int parseIntSafe(String s) {
        if (s == null || s.isBlank()) throw new NumberFormatException("missing int");
        return Integer.parseInt(s.trim());
    }

    private double parseDoubleSafe(String s) {
        if (s == null || s.isBlank()) throw new NumberFormatException("missing double");
        return Double.parseDouble(s.trim());
    }

    private String errorJson(String message) {
        return "{\"error\":" + quote(message) + "}";
    }

    private String quote(String s) {
        return "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"") + "\"";
    }

    private String readBody(HttpExchange exchange) throws IOException {
        try (InputStream is = exchange.getRequestBody()) {
            return new String(is.readAllBytes(), StandardCharsets.UTF_8);
        }
    }

    private void sendJson(HttpExchange exchange, int status, String json) throws IOException {
        byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
        exchange.sendResponseHeaders(status, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(bytes);
        }
    }
}
