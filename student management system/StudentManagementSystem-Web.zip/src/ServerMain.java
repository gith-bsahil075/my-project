import server.ApiServer;
import service.StudentService;

import java.io.IOException;
import java.nio.file.Path;

/**
 * Entry point for the WEB version of the Student Management System.
 * Starts the built-in HTTP server (backend) which also serves the
 * browser UI (frontend) from the /public folder.
 *
 * Run this class, then open http://localhost:8080 in a browser.
 *
 * (Main.java still exists separately as the console version — both
 * share the same model/dao/service layers underneath.)
 */
public class ServerMain {

    private static final int PORT = 8080;

    public static void main(String[] args) throws IOException {
        StudentService service = new StudentService();
        Path publicDir = Path.of("public").toAbsolutePath();

        if (!publicDir.toFile().exists()) {
            System.out.println("Could not find the 'public' folder at: " + publicDir);
            System.out.println("Make sure you run this from the project's root folder.");
            return;
        }

        new ApiServer(service, PORT).start(publicDir);
    }
}
