# Student Management System (Java SE 21)

A console-based Student Management System built with plain Java SE 21 —
no external libraries, no database driver, no Maven/Gradle required.
Designed to run directly in VS Code.

## Features
- Add Student
- View All Students
- Search Student by ID
- Update Student
- Delete Student
- Data automatically persists to `data/students.txt` (survives restarts)
- Input validation (duplicate IDs, blank names, age range, CGPA range 0-10)

## Project Structure
```
StudentManagementSystem/
├── src/
│   ├── Main.java                 -> console menu / entry point
│   ├── model/
│   │   └── Student.java          -> Student data model
│   ├── dao/
│   │   ├── StudentDAO.java       -> data-access interface
│   │   └── StudentDAOImpl.java   -> file-based implementation
│   └── service/
│       └── StudentService.java   -> business logic + validation
├── data/
│   └── students.txt              -> auto-created on first save
└── .vscode/                      -> run config for VS Code
```

This follows a layered design (Model -> DAO -> Service -> UI), the same
pattern used in the JDBC/SQLite version of this project, just with a
lightweight file-based DAO instead of a database — so it needs zero setup.

## How to Run in VS Code
1. Install the **Extension Pack for Java** (by Microsoft) from the Extensions
   marketplace, if you don't already have it.
2. Open this folder in VS Code: `File -> Open Folder -> StudentManagementSystem`.
3. Open `src/Main.java` and click **Run** above the `main` method
   (or press `F5`).
4. The interactive menu appears in the **Terminal** panel at the bottom.

## How to Run from a Terminal (no VS Code needed)
Requires JDK 21+ (`java -version` / `javac -version` to check).

```bash
# from inside the StudentManagementSystem folder
javac -d bin src/Main.java src/model/Student.java src/dao/StudentDAO.java src/dao/StudentDAOImpl.java src/service/StudentService.java
java -cp bin Main
```

## Notes
- Data is stored as plain CSV lines in `data/students.txt` — open it in any
  text editor to see it change as you use the app.
- Because everything is in a `data` DAO layer behind an interface, swapping
  in JDBC + SQLite later (like the GUI version) only means writing a new
  `StudentDAO` implementation — `Main` and `StudentService` wouldn't need
  to change.
